# Between Two Worlds ✦

A cinematic, interactive long-distance love letter: one miniature room in Germany, one in Tunisia, six hidden memories, and a bridge that lights up as memories are discovered. Her room includes **white tulips** and a music-box reveal for **BLOK3 — Sebebi Yar** and **The Weeknd — After Hours**. This edition is addressed to **Habibi** and contains the real 24-second voice recording and an unaltered crop from the original video-call screenshot.

## Open it

1. Download/extract the ZIP.
2. Open `index.html` in a web browser. No dependencies or build system are required.
3. Tap **Step into our world**.
4. Tap the glowing objects inside the two rooms. When three memories are discovered, the bridge unlocks a final surprise.

## Make it personal

Edit the text near the top of **`config.js`**:

- `name`: a nickname she likes
- `hisLocation` and `herLocation`: your preferred locations
- `secrets`: six short personalized discoveries
- `finalMessage` / `signature`: your most meaningful message
- `blok3Link` and `weekndLink`: optionally paste links to specific songs instead of general Spotify search
- `videoCallPhoto`: optionally add a consented photo at `assets/our-call.jpg`
- `voiceNote`: optionally add a recording at `assets/voice-note.mp3`

This version already includes the cropped photo (`assets/our-call.jpg`) in the laptop keepsake and final reveal, plus the voice note (`assets/for-habibi.mp3`) in the final reveal. The recording is played only when the visitor taps the audio control. You may remove the personal media files and clear their config paths if you prefer.

## Free GitHub Pages deployment

1. Create a **public GitHub repository**.
2. Upload **all the files** in this folder to the repository root (`index.html`, `styles.css`, `config.js`, `script.js`, etc.).
3. Go to **Settings → Pages → Build and deployment** and choose **Deploy from a branch**; choose `main` and `/ (root)`.
4. Wait for GitHub Pages to deploy. The link will look like `https://YOURUSERNAME.github.io/REPOSITORY/`.

No third-party code, accounts, or API keys needed to run. Font loading is optional; the site uses fallback fonts offline.

### Privacy and music

**IMPORTANT: This personalized version contains a real voice recording and your video-call image.** If you upload it to a public GitHub repository, anyone with the URL (or repository access) may download them. Do not publish this version unless you and your girlfriend agree. For a fully private version, use hosting with actual server-side authentication. **GitHub Pages sites from public repositories are public.** Don't put passwords, private details, or personal media online unless both of you are okay with them being accessible. A homemade JavaScript password form would not secure the content. For real access control, choose private hosting with server-side authentication instead.

The site does **not** copy or stream BLOK3 / The Weeknd songs. Its buttons open Spotify search or specific music links that you choose. The background ambience is generated locally with Web Audio and starts only after a user interaction.

## Files

- `index.html`: interface and illustrated rooms (all illustrations are inline SVG)
- `styles.css`: responsive design and animations
- `script.js`: interactions, progress, bridge, starfield, sound
- `config.js`: edit personal messages and optional media
- `assets/our-call.jpg`: original screenshot crop (faces unchanged)
- `assets/for-habibi.mp3`: your real 24-second voice message
