/**
 * BETWEEN TWO WORLDS — EDIT YOUR PERSONAL DETAILS HERE.
 * This is a static website. Anything added here is publicly visible if hosted on GitHub Pages.
 * Never put passwords, private information, or intimate photos in a public repository.
 */
window.WORLDS_CONFIG = {
  name: "Habibi",                 // The nickname you want her to see
  hisLocation: "DARMSTADT · GERMANY",
  herLocation: "TUNIS · TUNISIA",
  finalMessage:
    "Habibi, here is a little planet made just for you, full of tiny surprises, the music you love, and flowers that never fade. Maybe one day I will bring those white tulips to you for real. Until then, our two worlds will always meet here. ♡",
  signature: "MADE WITH LOVE, BY YOUR ENGINEER ♡",
  // Replace with a personal photo only if you both consent to it being on a public site.
  // e.g. "assets/our-call.jpg" — leave empty to display an illustrated keepsake instead.
  videoCallPhoto: "assets/our-call.jpg",
  // Optional custom recorded voice note. e.g. "assets/voice-note.mp3". No file needed for the demo.
  voiceNote: "assets/for-habibi.mp3",
  // Spotify search links open the artists in a new tab. They do not copy or embed copyrighted audio.
  blok3Link: "https://open.spotify.com/search/BLOK3%20Sebebi%20Yar",
  weekndLink: "https://open.spotify.com/search/The%20Weeknd%20After%20Hours",
  secrets: {
    "de-window": {
      chapter: "01 · HIS WINDOW",
      title: "Under the same sky",
      text: "Look out the window. Different streets, different nights… but the very same moon has a view of both of us. I like to think it keeps a little piece of my hello for you.",
      token: "✦",
    },
    "de-laptop": {
      chapter: "02 · THE LATE-NIGHT CALL",
      title: "Our little heart on a screen",
      text: "I could be doing a hundred things on my laptop, but seeing you on the other side of that screen always wins. Even that silly heart made with my hands was trying to say something words couldn't.",
      token: "♡",
    },
    "de-notebook": {
      chapter: "03 · A NOTE TO SELF",
      title: "Very important research",
      text: "Find a way to send hugs through Wi‑Fi. Learn how to teleport white tulips. Figure out how you manage to make ordinary days feel like stories worth keeping. (Progress: ongoing.)",
      token: "✎",
    },
    "tn-phone": {
      chapter: "04 · YOUR LITTLE SCREEN",
      title: "One tap closer",
      text: "I love the little moments, not just the big ones. The random messages. The laughs. The calls that make the rest of the world fade into the background.",
      token: "☏",
    },
    "tn-flower": {
      chapter: "05 · A BOUQUET JUST FOR YOU",
      title: "White tulips. Always.",
      text: "I know how much you love white tulips. These ones will never wilt, but they're really just a promise: one day I want to bring you a real bouquet, look you in the eyes, and give it to you myself.",
      token: "❀",
    },
    "tn-music": {
      chapter: "06 · THE SOUNDTRACK",
      title: "Sebebi Yar × After Hours",
      text: "For Habibi: two of your favorite songs, one little listening corner. BLOK3 — Sebebi Yar, and The Weeknd — After Hours. Pick a song and let this night feel a little more like ours.",
      token: "♫",
    },
  },
};
