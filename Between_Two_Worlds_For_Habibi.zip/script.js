(() => {
  'use strict';
  const cfg = window.WORLDS_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const keys = ['de-window', 'de-laptop', 'de-notebook', 'tn-phone', 'tn-flower', 'tn-music'];
  const token = new Set();
  let current = null;
  let previousFocus = null;
  let audioContext = null;
  let ambientInterval = null;
  let soundOn = false;
  let toastTimeout = 0;

  // Personalization: no HTML rendering of config text.
  $('hisLocation').textContent = cfg.hisLocation || 'GERMANY';
  $('herLocation').textContent = cfg.herLocation || 'TUNISIA';
  $('footerName').textContent = (cfg.name || 'SOMEONE VERY SPECIAL').toUpperCase();
  $('endingMessage').textContent = cfg.finalMessage || 'One sky, two hearts.';
  $('endingSignature').textContent = cfg.signature || 'WITH LOVE';

  const iconTulips = `<svg class="tulip-art" role="img" aria-label="A hand-drawn bouquet of white tulips" viewBox="0 0 320 155" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="pStem" x2="1" y2="1"><stop stop-color="#8ba998"/><stop offset="1" stop-color="#507d74"/></linearGradient></defs><path d="M155 143 103 48m59 91 7-104m-9 106 61-93m-58 90 19-82m-24 81-51-73" fill="none" stroke="url(#pStem)" stroke-width="4" stroke-linecap="round"/><path d="m152 120-31-33q25-9 39 41m0-31 34-33q12 23-31 54m-45-22-24-26q22-2 32 31m54-7 27-31q9 25-27 42" fill="#79a58e" opacity=".85"/><g fill="#fffaf1" stroke="#e4d8e1" stroke-width="2.1"><path d="M88 58q-20-38-9-53 10 14 22 2 15 10 6 42-8 21-19 9Z"/><path d="M158 50q-16-39-5-49 11 12 24 0 14 11 0 48-9 22-19 1Z"/><path d="M207 61q-12-34-2-49 11 12 24 0 12 12 0 47-13 20-22 2Z"/><path d="M166 67q-15-32-4-46 10 14 21 2 13 15-2 45-7 12-15-1Z"/><path d="M108 69q-12-32-4-44 10 13 23 1 12 14-4 41-7 14-15 2Z"/></g><path d="m88 15 7 35 11-35m57 3 6 28 9-31m34 11 7 28 9-25" stroke="#fff" stroke-width="1.8" fill="none" opacity=".8"/><path d="m146 123 23 7 19-9-13 30-25-1Z" fill="#e9c1c9"/><path d="m145 127 39 10" stroke="#fff4ed" stroke-width="2"/></svg>`;

  function safeMediaPath(value) {
    if (typeof value !== 'string' || !value.trim()) return '';
    const url = value.trim();
    // Prevent unsafe URL schemes; allow relative site assets and https links.
    return /^assets\/[\w./-]+$/i.test(url) || /^https:\/\/[^\s]+$/i.test(url) ? url : '';
  }
  function safeExternalLink(value, fallback) {
    return typeof value === 'string' && /^https:\/\//i.test(value) ? value : fallback;
  }
  function getSecret(key) {
    const defaults = {
      chapter:'A LITTLE DISCOVERY', title:'A little secret',
      text:'I left this here because it reminded me of you.',token:'✦'
    };
    return Object.assign({}, defaults, cfg.secrets && cfg.secrets[key] || {});
  }

  function showToast(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.remove('hidden');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toast.classList.add('hidden'), 2400);
  }
  function showApp() {
    $('welcome').classList.add('hidden');
    $('app').classList.remove('hidden');
    $('app').setAttribute('aria-hidden', 'false');
    window.scrollTo({top:0,behavior:'instant'});
    $('soundBtn').focus({preventScroll:true});
    playDiscovery(440);
  }
  $('enterBtn').addEventListener('click', showApp);

  function renderExtraMedia(key) {
    const media = $('modalMedia');
    media.replaceChildren();
    media.classList.add('hidden');
    if (key === 'tn-flower') {
      media.innerHTML = iconTulips;
      media.classList.remove('hidden');
    } else if (key === 'tn-music') {
      const choices = document.createElement('div');
      choices.className = 'music-choices';
      const links = [
        ['BLOK3 · Sebebi Yar', safeExternalLink(cfg.blok3Link, 'https://open.spotify.com/search/BLOK3%20Sebebi%20Yar')],
        ['The Weeknd · After Hours', safeExternalLink(cfg.weekndLink, 'https://open.spotify.com/search/The%20Weeknd%20After%20Hours')]
      ];
      links.forEach(([label, url]) => {
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.target = '_blank';
        anchor.rel = 'noopener noreferrer';
        anchor.className = 'music-choice';
        anchor.textContent = `♫ ${label} ↗`;
        choices.append(anchor);
      });
      const note = document.createElement('small');
      note.className = 'media-note';
      note.textContent = 'Tap to open the songs on Spotify. Music is not copied into this website.';
      media.append(choices, note);
      media.classList.remove('hidden');
    } else if (key === 'de-laptop') {
      const src = safeMediaPath(cfg.videoCallPhoto);
      if (src) {
        const img = document.createElement('img');
        img.src = src;
        img.alt = 'A favorite memory from our video call';
        img.loading = 'lazy';
        img.addEventListener('error', () => {
          media.replaceChildren();
          media.classList.add('hidden');
        });
        media.append(img);
      } else {
        const placeholder = document.createElement('div');
        placeholder.className = 'photo-fallback';
        placeholder.innerHTML = '<span>♡</span> One screen. Two smiles.\nA moment I kept.';
        media.append(placeholder);
      }
      media.classList.remove('hidden');
    }
  }

  function openMemory(key) {
    if (!keys.includes(key)) return;
    current = key;
    previousFocus = document.activeElement;
    const info = getSecret(key);
    $('modalCategory').textContent = info.chapter;
    $('modalTitle').textContent = info.title;
    $('modalText').textContent = info.text;
    $('modalIndex').textContent = `${String(keys.indexOf(key)+1).padStart(2,'0')} / 06`;
    $('modalDone').innerHTML = (token.has(key) ? 'Keep this close ' : 'Keep this memory ') + '<span>↗</span>';
    renderExtraMedia(key);
    $('memoryModal').classList.remove('hidden');
    $('memoryModal').setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    $('closeModal').focus({preventScroll:true});
    playDiscovery(600);
  }
  function closeModal() {
    $('memoryModal').classList.add('hidden');
    $('memoryModal').setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    previousFocus && previousFocus.focus({preventScroll:true});
  }
  document.querySelectorAll('.clickable-object').forEach((obj) => {
    const handler = () => openMemory(obj.dataset.secret);
    obj.addEventListener('click', handler);
    obj.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault(); handler();
      }
    });
  });
  $('closeModal').addEventListener('click',closeModal);
  document.querySelectorAll('[data-close="modal"]').forEach(el=>el.addEventListener('click',closeModal));
  $('modalDone').addEventListener('click', () => {
    if (current && !token.has(current)) {
      token.add(current);
      refreshProgress();
      if (token.size === 3) showToast('A new path is glowing between your worlds ✦');
      else showToast('A little memory, safely kept ♡');
    }
    closeModal();
  });

  function refreshProgress() {
    $('progressLabel').textContent = `${token.size} of 6 little discoveries found`;
    $('progressFill').style.width = `${token.size/6*100}%`;
    $('notebookCount').textContent = `${String(token.size).padStart(2,'0')} / 06 FOUND`;
    const list = $('keepsakes');
    list.replaceChildren();
    if (!token.size) {
      const empty = document.createElement('p');
      empty.className = 'keepsakes__empty';
      empty.textContent = 'Your collection is still waiting for its first little memory. ✧';
      list.append(empty);
    } else {
      keys.filter(k => token.has(k)).forEach(key => {
        const info = getSecret(key);
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'keepsake';
        button.addEventListener('click',()=>openMemory(key));
        const symbol = document.createElement('span');symbol.className='keepsake__symbol';symbol.textContent=info.token;
        const detail = document.createElement('span');detail.className='keepsake__details';
        const chapter = document.createElement('span');chapter.className='keepsake__chapter';chapter.textContent=info.chapter;
        const title = document.createElement('span');title.className='keepsake__title';title.textContent=info.title;
        detail.append(chapter,title);button.append(symbol,detail);list.append(button);
      });
    }
    document.querySelectorAll('.clickable-object').forEach(obj=>obj.classList.toggle('is-found',token.has(obj.dataset.secret)));
    const ready = token.size >= 3;
    $('bridgeBtn').disabled = !ready;
    $('bridgeBtnText').textContent = ready ? 'Bring our two worlds together' : `Discover ${3-token.size} more ${3-token.size===1?'keepsake':'keepsakes'} to connect`;
    $('bridgeCount').textContent = `${Math.min(token.size,3)} / 3`;
    Array.from($('bridgeDots').children).forEach((dot,index)=>dot.classList.toggle('lit',index<token.size));
    if (ready) $('bridgeDescription').textContent = 'You found the little things. Now look what they can make together.';
  }
  refreshProgress();
  $('endingBouquet').innerHTML = iconTulips;

  function makeEndingParticles() {
    const holder = $('endingParticles');
    if (holder.childNodes.length) return;
    for (let i=0;i<42;i++) {
      const dot = document.createElement('span');
      dot.textContent = (i%7===0)?'❀':'✦';
      dot.style.left = `${(i*53.7)%99}%`;
      dot.style.setProperty('--duration',`${6+(i%9)*.73}s`);
      dot.style.setProperty('--size',`${8+(i%5)*3}px`);
      dot.style.animationDelay = `${-(i%13)*.82}s`;
      holder.append(dot);
    }
  }
  function openEnding() {
    if (token.size<3) return;
    makeEndingParticles();
    const note = safeMediaPath(cfg.voiceNote);
    const previousNote = $('ending').querySelector('audio');
    if (previousNote) previousNote.remove();
    if (note) {
      const player = document.createElement('audio');
      player.controls = true;player.preload='none';player.className='voice-note';player.src=note;
      player.setAttribute('aria-label','A personal 24-second voice message for Habibi');
      $('voiceIntro').after(player);
    }
    $('ending').classList.remove('hidden');
    $('ending').setAttribute('aria-hidden','false');
    document.body.style.overflow='hidden';
    $('endingClose').focus({preventScroll:true});
    playDiscovery(880);
  }
  function closeEnding() {
    $('ending').classList.add('hidden');
    $('ending').setAttribute('aria-hidden','true');
    $('ending').querySelectorAll('audio').forEach(player=>player.pause());
    document.body.style.overflow='';
    $('bridgeBtn').focus({preventScroll:true});
  }
  $('bridgeBtn').addEventListener('click',openEnding);
  $('endingClose').addEventListener('click',closeEnding);
  $('endingReplay').addEventListener('click',()=>{closeEnding();window.scrollTo({top:0,behavior:'smooth'});});
  $('restartBtn').addEventListener('click',()=>{
    token.clear();refreshProgress();closeModal();closeEnding();window.scrollTo({top:0,behavior:'smooth'});showToast('A new adventure starts here ✦');
  });
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape') {
      if(!$('ending').classList.contains('hidden'))closeEnding();
      else if(!$('memoryModal').classList.contains('hidden'))closeModal();
    }
    // Keep keyboard focus within the current dialog for accessibility.
    if(event.key!=='Tab')return;
    const dialog=!$('ending').classList.contains('hidden')?$('ending'):(!$('memoryModal').classList.contains('hidden')?$('memoryModal'):null);
    if (!dialog)return;
    const focusables=Array.from(dialog.querySelectorAll('button:not([disabled]),a[href],audio[controls]'));
    if (!focusables.length)return;
    let pos=focusables.indexOf(document.activeElement);
    if(event.shiftKey && (pos===0||pos===-1)){event.preventDefault();focusables[focusables.length-1].focus();}
    if(!event.shiftKey && pos===focusables.length-1){event.preventDefault();focusables[0].focus();}
  });

  // Opt-in generative ambient chimes: no external copyrighted songs or streams.
  const waves=$('soundWaves');
  const soundBtn=$('soundBtn');
  function tone(freq=440,delay=0,level=.025) {
    if (!soundOn) return;
    try {
      if (!audioContext)audioContext=new (window.AudioContext||window.webkitAudioContext)();
      if(audioContext.state==='suspended')audioContext.resume();
      const start=audioContext.currentTime+delay;
      const osc=audioContext.createOscillator();const amp=audioContext.createGain();
      osc.type='sine';osc.frequency.value=freq;
      amp.gain.setValueAtTime(.0001,start);
      amp.gain.exponentialRampToValueAtTime(level,start+.035);
      amp.gain.exponentialRampToValueAtTime(.0001,start+1.75);
      osc.connect(amp).connect(audioContext.destination);osc.start(start);osc.stop(start+1.8);
    } catch(err) { console.warn('Sound unavailable',err); }
  }
  function playDiscovery(note){tone(note,0,.02);tone(note*1.5,.12,.012);}
  function playAmbient(){
    const root=[220,261.63,329.63,293.66];
    const i=Math.floor(Date.now()/4900)%root.length;
    tone(root[i],0,.009);tone(root[i]*1.5,.35,.006);
  }
  soundBtn.addEventListener('click',()=>{
    soundOn=!soundOn;
    soundBtn.setAttribute('aria-pressed',String(soundOn));
    soundBtn.setAttribute('aria-label',soundOn?'Mute gentle sound':'Enable gentle sound');
    waves.style.opacity=soundOn?'1':'.32';
    if(ambientInterval){clearInterval(ambientInterval);ambientInterval=null;}
    if(soundOn){playDiscovery(523.25);ambientInterval=setInterval(()=>{if(!document.hidden)playAmbient();},5500);showToast('Gentle sound enabled ♫');}
    else showToast('Sound turned off');
  });
  waves.style.opacity='.32';
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&soundOn)playAmbient();});

  // Calm background starfield. Honors reduced motion, works without any graphics libraries.
  const canvas=$('sky');const ctx=canvas.getContext('2d');
  if(ctx) {
    const reduceMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let stars=[],width=0,height=0,raf=null;
    function resize() {
      const dpr=Math.min(window.devicePixelRatio||1,2);
      width=window.innerWidth;height=window.innerHeight;
      canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const count=Math.min(135,Math.floor(width*height/6800));
      stars=Array.from({length:count},(_,i)=>({x:(i*127.153+29)%width,y:(i*97.529+71)%height,r:.45+(i%5)*.25,speed:.2+(i%8)*.09,phase:i*3.141}));
    }
    function render(t) {
      ctx.clearRect(0,0,width,height);
      stars.forEach(star=>{
        const fade=reduceMotion?.62:(.3+.46*(.5+.5*Math.sin(t*.00055*star.speed+star.phase)));
        ctx.fillStyle=`rgba(246,228,249,${fade})`;
        ctx.beginPath();ctx.arc(star.x,star.y,star.r,0,Math.PI*2);ctx.fill();
      });
      if(!reduceMotion)raf=requestAnimationFrame(render);
    }
    resize();render(0);
    window.addEventListener('resize',()=>{resize();if(reduceMotion)render(0);},{passive:true});
    window.addEventListener('pagehide',()=>{if(raf)cancelAnimationFrame(raf);});
  }
})();
